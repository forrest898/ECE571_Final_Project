int32_t vfork(void);
