int32_t nanosleep(const struct timespec *req, struct timespec *rem);
