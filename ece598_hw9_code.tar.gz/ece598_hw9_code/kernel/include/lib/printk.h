int printk(char *string,...);
int serial_printk(char *string,...);
int sprintf(char *buffer,...);

