void *memset(void *s, int c, uint32_t n);
void *memset_byte(void *s, int c, uint32_t n);
void *memset_4byte(void *s, int c, uint32_t n);
void *memset_asm(void *s, int c, uint32_t n);

