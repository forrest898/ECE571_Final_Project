uint32_t div32(uint32_t dividend, uint32_t divisor);
