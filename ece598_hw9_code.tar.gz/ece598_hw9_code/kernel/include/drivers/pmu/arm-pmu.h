int pmu_init(void);
uint32_t read_cycle_counter(void);
