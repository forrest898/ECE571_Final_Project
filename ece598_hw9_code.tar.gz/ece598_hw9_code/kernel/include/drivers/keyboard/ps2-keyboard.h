int ps2_interrupt_handler(void);
int ps2_keyboard_init(void);
void ps2_keyboard_cleanup(void);
