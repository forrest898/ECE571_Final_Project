void bcm2835_write(uint32_t address, uint32_t data);
uint32_t bcm2835_read(uint32_t address);
