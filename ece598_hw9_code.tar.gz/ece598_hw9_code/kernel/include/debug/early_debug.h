uint32_t early_debug_init(void);
void early_debug_dump_memory(uint32_t address, uint32_t size);
