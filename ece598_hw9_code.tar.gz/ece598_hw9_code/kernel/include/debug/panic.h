void dump_saved_user_state(struct process_control_block_type *proc);
void dump_saved_kernel_state(struct process_control_block_type *proc);
void dump_kernel_regs(void);
void dump_memory(uint32_t address,uint32_t size);
